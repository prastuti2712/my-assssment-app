// ArtworkEntity.kt
package com.example.myassssmentapplication

import java.io.Serializable

data class ArtworkEntity(
    val artworkTitle: String,
    val artist: String,
    val medium: String,
    val year: String,
    val description: String




) : Serializable
