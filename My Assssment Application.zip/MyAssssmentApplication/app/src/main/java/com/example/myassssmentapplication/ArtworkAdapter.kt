package com.example.myassssmentapplication

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ArtworkAdapter(
    private val context: Context,
    private var artworkList: List<ArtworkEntity>,
    private val onItemClick: (ArtworkEntity) -> Unit
) : RecyclerView.Adapter<ArtworkAdapter.ArtworkViewHolder>() {

    inner class ArtworkViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titleTextView: TextView = itemView.findViewById(R.id.titleTextView)
        val artistTextView: TextView = itemView.findViewById(R.id.artistTextView)
        val yearTextView: TextView = itemView.findViewById(R.id.yearTextView)
        val descriptionTextView: TextView = itemView.findViewById(R.id.descriptionTextView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ArtworkViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_artwork, parent, false)
        return ArtworkViewHolder(view)
    }

    override fun onBindViewHolder(holder: ArtworkViewHolder, position: Int) {
        val artwork = artworkList[position]
        holder.titleTextView.text = artwork.artworkTitle
        holder.artistTextView.text = artwork.artist
        holder.yearTextView.text = artwork.year
        holder.descriptionTextView.text = artwork.description

        holder.itemView.setOnClickListener {
            onItemClick(artwork)
        }
    }

    override fun getItemCount(): Int = artworkList.size

    fun updateData(newArtworkList: List<ArtworkEntity>) {
        artworkList = newArtworkList
        notifyDataSetChanged()
    }
}
