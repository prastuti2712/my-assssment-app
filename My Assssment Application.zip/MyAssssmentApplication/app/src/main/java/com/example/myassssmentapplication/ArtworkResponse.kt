package com.example.myassssmentapplication

data class ArtworkResponse(
    val entities: List<ArtworkEntity>,
    val entityTotal: Int
)


