package com.example.myassssmentapplication.api

import com.example.myassssmentapplication.ArtworkResponse
import com.example.myassssmentapplication.LoginRequest
import com.example.myassssmentapplication.LoginResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface ApiService {

    @POST("sydney/auth")
    fun login(@Body request: LoginRequest): Call<LoginResponse>

    @GET("dashboard/{keypass}")
    fun getEntities(@Path("keypass") keypass: String): Call<ArtworkResponse>
}
