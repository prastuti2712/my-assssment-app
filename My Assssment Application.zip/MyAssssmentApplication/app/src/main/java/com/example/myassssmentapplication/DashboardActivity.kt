package com.example.myassssmentapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myassssmentapplication.api.ApiService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DashboardActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ArtworkAdapter
    private lateinit var logoutButton: Button  // Add logout button variable

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        recyclerView = findViewById(R.id.recyclerView)
        logoutButton = findViewById(R.id.logoutButton)  // Link logout button from XML

        recyclerView.layoutManager = LinearLayoutManager(this)

        adapter = ArtworkAdapter(this, listOf()) { selectedArtwork ->
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra("artwork", selectedArtwork)
            startActivity(intent)
        }
        recyclerView.adapter = adapter

        logoutButton.setOnClickListener {
            logout()
        }

        val keypass = intent.getStringExtra("KEYPASS") ?: ""
        if (keypass.isBlank()) {
            Toast.makeText(this, "Keypass missing from login", Toast.LENGTH_LONG).show()
            return
        }

        fetchDashboardData(keypass)
    }

    private fun fetchDashboardData(keypass: String) {
        val api = RetrofitClient.getInstance().create(ApiService::class.java)
        api.getEntities(keypass).enqueue(object : Callback<ArtworkResponse> {
            override fun onResponse(call: Call<ArtworkResponse>, response: Response<ArtworkResponse>) {
                if (response.isSuccessful && response.body() != null) {
                    adapter.updateData(response.body()!!.entities)
                } else {
                    Toast.makeText(this@DashboardActivity, "Error: ${response.code()}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ArtworkResponse>, t: Throwable) {
                Toast.makeText(this@DashboardActivity, "Failed to load: ${t.message}", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun logout() {
        // Clear stored user data (if any) in SharedPreferences
        val sharedPref = getSharedPreferences("MyAppPrefs", MODE_PRIVATE)
        sharedPref.edit().clear().apply()

        // Navigate back to login screen
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}
