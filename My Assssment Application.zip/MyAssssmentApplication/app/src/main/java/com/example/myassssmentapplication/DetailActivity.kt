package com.example.myassssmentapplication

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val artwork = intent.getSerializableExtra("artwork") as? ArtworkEntity

        findViewById<TextView>(R.id.tvTitle).text = artwork?.artworkTitle
        findViewById<TextView>(R.id.tvArtist).text = artwork?.artist
        findViewById<TextView>(R.id.tvMedium).text = artwork?.medium
        findViewById<TextView>(R.id.tvYear).text = artwork?.year.toString()
        findViewById<TextView>(R.id.tvDescription).text = artwork?.description
    }
}
